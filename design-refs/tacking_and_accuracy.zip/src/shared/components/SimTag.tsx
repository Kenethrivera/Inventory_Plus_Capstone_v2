import React from 'react'
import { FlaskConical } from 'lucide-react'

/** Marks any figure or chart that comes from synthetic simulated sales, never real store data. */
export function SimTag({ label = 'Synthetic simulation' }: { label?: string }) {
  return (
    <span className="inline-flex shrink-0 items-center gap-1 whitespace-nowrap rounded-md border border-dashed border-sim/40 bg-sim-soft px-1.5 py-0.5 text-[11px] font-medium text-sim">
      <FlaskConical size={11} />
      {label}
    </span>
  )
}
