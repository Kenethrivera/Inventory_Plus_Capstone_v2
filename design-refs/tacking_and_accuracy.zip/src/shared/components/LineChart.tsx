import React from 'react'

export type Series = {
  label: string
  values: number[]
  color: string
  dashed?: boolean
}

type Props = {
  labels: string[]
  series: Series[]
  height?: number
  unit?: string
  highlightIndex?: number | null
  onPointClick?: (i: number) => void
}

const W = 640

/** Small dependency-free SVG line chart with gridlines, a legend and an optional highlighted point. */
export function LineChart({ labels, series, height = 220, unit = '', highlightIndex = null, onPointClick }: Props) {
  const pad = { t: 12, r: 12, b: 26, l: 40 }
  const all = series.flatMap((s) => s.values)
  const max = niceMax(Math.max(...all, 1))
  const innerW = W - pad.l - pad.r
  const innerH = height - pad.t - pad.b
  const n = labels.length
  const x = (i: number) => pad.l + (n === 1 ? innerW / 2 : (i / (n - 1)) * innerW)
  const y = (v: number) => pad.t + innerH - (v / max) * innerH
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(max * f))
  const labelEvery = Math.ceil(n / 8)

  return (
    <div>
      <div className="mb-2 flex flex-wrap gap-x-4 gap-y-1">
        {series.map((s) => (
          <span key={s.label} className="inline-flex items-center gap-1.5 text-xs text-muted">
            <svg width="16" height="6">
              <line x1="0" y1="3" x2="16" y2="3" stroke={s.color} strokeWidth="2" strokeDasharray={s.dashed ? '4 3' : undefined} />
            </svg>
            {s.label}
          </span>
        ))}
      </div>
      <svg viewBox={`0 0 ${W} ${height}`} className="h-auto w-full" role="img">
        {ticks.map((t) => (
          <g key={t}>
            <line x1={pad.l} x2={W - pad.r} y1={y(t)} y2={y(t)} stroke="#eceef2" />
            <text x={pad.l - 8} y={y(t) + 3.5} textAnchor="end" fontSize="10" fill="#9aa1ad">
              {t}
              {unit}
            </text>
          </g>
        ))}
        {labels.map((l, i) =>
          i % labelEvery === 0 || i === n - 1 ? (
            <text key={i} x={x(i)} y={height - 8} textAnchor="middle" fontSize="10" fill="#9aa1ad">
              {l}
            </text>
          ) : null,
        )}
        {highlightIndex !== null && highlightIndex >= 0 && (
          <line x1={x(highlightIndex)} x2={x(highlightIndex)} y1={pad.t} y2={pad.t + innerH} stroke="#ea6a10" strokeOpacity="0.35" strokeDasharray="3 3" />
        )}
        {series.map((s) => (
          <g key={s.label}>
            <polyline
              fill="none"
              stroke={s.color}
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
              strokeDasharray={s.dashed ? '5 4' : undefined}
              points={s.values.map((v, i) => `${x(i)},${y(v)}`).join(' ')}
            />
            {s.values.map((v, i) => (
              <circle
                key={i}
                cx={x(i)}
                cy={y(v)}
                r={highlightIndex === i ? 4 : n <= 12 ? 2.5 : 0}
                fill={highlightIndex === i ? s.color : '#fff'}
                stroke={s.color}
                strokeWidth="1.5"
              />
            ))}
          </g>
        ))}
        {onPointClick &&
          labels.map((_, i) => (
            <rect
              key={i}
              x={x(i) - innerW / n / 2}
              y={pad.t}
              width={innerW / n}
              height={innerH}
              fill="transparent"
              className="cursor-pointer"
              onClick={() => onPointClick(i)}
            />
          ))}
      </svg>
    </div>
  )
}

function niceMax(v: number) {
  const mag = Math.pow(10, Math.floor(Math.log10(v)))
  const steps = [1, 1.2, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]
  for (const s of steps) if (s * mag >= v * 1.05) return s * mag
  return 10 * mag
}
