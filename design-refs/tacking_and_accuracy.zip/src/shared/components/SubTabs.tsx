import React from 'react'

type Props<T extends string> = {
  value: T
  options: { id: T; label: string }[]
  onChange: (v: T) => void
}

/** Compact segmented control used for sub-navigation inside a forecasting tab. */
export function SubTabs<T extends string>({ value, options, onChange }: Props<T>) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
      <div className="inline-flex min-w-max rounded-lg bg-line/70 p-0.5">
        {options.map((o) => {
          const active = o.id === value
          return (
            <button
              key={o.id}
              onClick={() => onChange(o.id)}
              className={`whitespace-nowrap rounded-md px-3 py-1.5 text-[13px] font-medium transition-colors duration-150 ${
                active ? 'bg-surface text-ink shadow-sm' : 'text-muted hover:text-ink'
              }`}
            >
              {o.label}
            </button>
          )
        })}
      </div>
    </div>
  )
}
