import React, { useState } from 'react'
import {
  LayoutDashboard,
  ShoppingCart,
  Boxes,
  Package,
  ReceiptText,
  TrendingUp,
  BarChart3,
  Settings,
  Menu,
  X,
  Wrench,
} from 'lucide-react'

export type ForecastTab = 'overview' | 'product' | 'tracking' | 'research'

const TABS: { id: ForecastTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'product', label: 'Product Forecast' },
  { id: 'tracking', label: 'Tracking & Accuracy' },
  { id: 'research', label: 'Research' },
]

const NAV = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Point of Sale', icon: ShoppingCart },
  { label: 'Inventory', icon: Boxes },
  { label: 'Products', icon: Package },
  { label: 'Receipts', icon: ReceiptText },
  { label: 'Forecasting & Restocking', icon: TrendingUp, active: true },
  { label: 'Reports', icon: BarChart3 },
  { label: 'Settings', icon: Settings },
]

type Props = {
  activeTab: ForecastTab
  onTabChange?: (tab: ForecastTab) => void
  children: React.ReactNode
}

export function AppShell({ activeTab, onTabChange, children }: Props) {
  const [navOpen, setNavOpen] = useState(false)

  return (
    <div className="flex h-screen w-full overflow-hidden bg-page text-ink">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 flex w-60 flex-col bg-sidebar text-white/80 transition-transform duration-200 ease-[cubic-bezier(0.23,1,0.32,1)] lg:static lg:translate-x-0 ${
          navOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex h-16 items-center gap-2.5 px-5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-white">
            <Wrench size={16} strokeWidth={2.4} />
          </span>
          <span className="text-[15px] font-semibold text-white">Inventory Plus</span>
          <button
            className="ml-auto rounded-md p-1 text-white/70 hover:bg-white/10 lg:hidden"
            onClick={() => setNavOpen(false)}
            aria-label="Close menu"
          >
            <X size={18} />
          </button>
        </div>
        <nav className="flex-1 space-y-0.5 px-3 py-2">
          {NAV.map(({ label, icon: Icon, active }) => (
            <a
              key={label}
              href="#"
              onClick={(e) => e.preventDefault()}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-[13px] font-medium transition-colors duration-150 ${
                active ? 'bg-accent text-white' : 'hover:bg-white/8 hover:text-white'
              }`}
            >
              <Icon size={17} />
              <span className="truncate">{label}</span>
            </a>
          ))}
        </nav>
        <div className="border-t border-white/10 px-5 py-4">
          <p className="text-[13px] font-medium text-white">Ramon Dela Cruz</p>
          <p className="text-xs text-white/50">Owner · Dela Cruz Hardware</p>
        </div>
      </aside>
      {navOpen && (
        <div className="fixed inset-0 z-30 bg-black/30 lg:hidden" onClick={() => setNavOpen(false)} />
      )}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-3 border-b border-line bg-surface px-4 lg:hidden">
          <button
            className="rounded-md p-1.5 text-body hover:bg-subtle"
            onClick={() => setNavOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={20} />
          </button>
          <span className="text-sm font-semibold">Inventory Plus</span>
        </header>

        <main className="min-h-0 flex-1 overflow-y-auto">
          <div className="mx-auto w-full max-w-[1200px] px-4 pb-12 pt-5 sm:px-6 lg:px-8 lg:pt-7">
            <div className="mb-4">
              <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">Forecasting &amp; Restocking</h1>
              <p className="mt-1 text-[13px] text-muted">
                28-day demand forecasts and preliminary restocking recommendations
              </p>
            </div>

            <div className="-mx-4 mb-6 overflow-x-auto border-b border-line px-4 sm:mx-0 sm:px-0">
              <div className="flex min-w-max gap-1">
                {TABS.map((t) => {
                  const active = t.id === activeTab
                  return (
                    <button
                      key={t.id}
                      onClick={() => onTabChange?.(t.id)}
                      className={`relative whitespace-nowrap px-3.5 py-2.5 text-[13px] font-medium transition-colors duration-150 ${
                        active ? 'text-accent' : 'text-muted hover:text-ink'
                      }`}
                    >
                      {t.label}
                      {active && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent" />}
                    </button>
                  )
                })}
              </div>
            </div>

            {children}
          </div>
        </main>
      </div>
    </div>
  )
}
