/**
 * Seasonal Learning Laboratory — frozen offline research results.
 * Every figure here comes from SYNTHETIC simulated sales, not real customer purchases.
 */

export const STUDY = {
  name: 'Frozen offline evaluation v1.3',
  products: 48,
  simulatedHistory: 'Jan 2022 – Dec 2024',
  holdout: '6 consecutive 28-day windows (Jul 21 – Dec 2024)',
}

export type ModelResult = { model: string; note: string; wape: number; bias: number; operational?: boolean }

/** Bias is identical at both granularities because the totals being compared are the same. */
export const EVALUATION: Record<'daily' | 'aggregate', ModelResult[]> = {
  aggregate: [
    { model: 'Calibrated seasonal', note: 'Used by Inventory Plus', wape: 21.3, bias: 1.6, operational: true },
    { model: '28-day moving average', note: 'Average of the last 28 days', wape: 29.8, bias: 3.8 },
    { model: 'Seasonal naïve', note: 'Repeats the same period last year', wape: 33.5, bias: -2.1 },
  ],
  daily: [
    { model: 'Calibrated seasonal', note: 'Used by Inventory Plus', wape: 52.7, bias: 1.6, operational: true },
    { model: '28-day moving average', note: 'Average of the last 28 days', wape: 61.4, bias: 3.8 },
    { model: 'Seasonal naïve', note: 'Repeats the same period last year', wape: 68.9, bias: -2.1 },
  ],
}

export const WINDOW_LABELS = [
  'Jan 6', 'Feb 3', 'Mar 3', 'Mar 31', 'Apr 28', 'May 26', 'Jun 23',
  'Jul 21', 'Aug 18', 'Sep 15', 'Oct 13', 'Nov 10', 'Dec 8',
]

export type ReplayProduct = {
  id: string
  product: string
  unit: string
  season: 'SUMMER' | 'RAINY' | 'NEUTRAL'
  simulatedDemand: number[]
  forecast: number[]
}

/** 28-day totals at each forecast origin across one simulated year. */
export const REPLAY: ReplayProduct[] = [
  {
    id: 'sealant',
    product: 'Waterproofing Sealant 300ml',
    unit: 'tubes',
    season: 'RAINY',
    simulatedDemand: [30, 28, 26, 31, 40, 62, 88, 95, 90, 70, 48, 36, 32],
    forecast: [33, 30, 27, 28, 34, 49, 74, 92, 94, 80, 55, 40, 34],
  },
  {
    id: 'cement',
    product: 'Portland Cement 40kg',
    unit: 'bags',
    season: 'SUMMER',
    simulatedDemand: [150, 162, 190, 205, 198, 170, 140, 128, 132, 145, 150, 148, 135],
    forecast: [146, 155, 176, 198, 204, 182, 152, 135, 130, 140, 148, 150, 142],
  },
  {
    id: 'pvc',
    product: 'PVC Pipe ½in × 10ft',
    unit: 'lengths',
    season: 'NEUTRAL',
    simulatedDemand: [112, 118, 109, 121, 115, 119, 110, 117, 122, 114, 120, 126, 118],
    forecast: [115, 114, 116, 113, 118, 116, 117, 113, 116, 119, 116, 119, 122],
  },
]

export const SEASONS = ['SUMMER', 'RAINY', 'NEUTRAL'] as const
export const PREDICTED = ['SUMMER', 'RAINY', 'NEUTRAL', 'UNKNOWN'] as const

export type ClassMethod = {
  id: string
  method: string
  description: string
  /** rows: simulated reference SUMMER / RAINY / NEUTRAL; cols: predicted SUMMER / RAINY / NEUTRAL / UNKNOWN */
  matrix: number[][]
}

export const CLASS_METHODS: ClassMethod[] = [
  {
    id: 'harmonic',
    method: 'Harmonic regression + rules',
    description: 'Fits yearly sine/cosine terms to weekly sales, then labels the peak month window.',
    matrix: [
      [12, 0, 1, 1],
      [0, 10, 1, 1],
      [1, 1, 17, 3],
    ],
  },
  {
    id: 'gmm',
    method: 'Gaussian mixture',
    description: 'Clusters normalised monthly sales profiles with soft assignment.',
    matrix: [
      [11, 0, 2, 1],
      [1, 9, 1, 1],
      [2, 1, 17, 2],
    ],
  },
  {
    id: 'kmeans',
    method: 'K-means clustering',
    description: 'Groups normalised monthly sales profiles into fixed clusters, then names them.',
    matrix: [
      [11, 1, 2, 0],
      [1, 9, 2, 0],
      [2, 2, 16, 2],
    ],
  },
  {
    id: 'rules',
    method: 'Monthly share thresholds',
    description: 'Labels a product by the share of yearly sales in Mar–May or Jun–Oct.',
    matrix: [
      [10, 0, 2, 2],
      [0, 8, 2, 2],
      [1, 1, 16, 4],
    ],
  },
]

export const CLASS_FINDINGS = [
  'RAINY items with short peaks were most often labelled NEUTRAL.',
  'UNKNOWN was assigned mainly to products with under 12 months of simulated history.',
  'No method was evaluated against real store season labels.',
]

export const LIMITATIONS = [
  {
    title: 'Synthetic sales',
    body: 'Research results are based primarily on synthetic simulated sales.',
  },
  {
    title: 'Not real customer behaviour',
    body: 'Simulated demand is not equivalent to real customer purchasing behaviour, including promotions, stockouts and local events.',
  },
  {
    title: 'No automatic reclassification',
    body: 'Experimental seasonal methods do not automatically update the season assigned to products in Inventory.',
  },
  {
    title: 'Past fit is not future accuracy',
    body: 'Historical backtesting and replay do not prove future accuracy.',
  },
  {
    title: 'Real-store validation needed',
    body: 'Further validation on real store sales is required. Operational forecast accuracy is reported in Tracking & Accuracy.',
  },
]

export function classMetrics(matrix: number[][]) {
  const total = matrix.flat().reduce((a, b) => a + b, 0)
  const correct = matrix.reduce((s, row, i) => s + row[i], 0)
  const unknown = matrix.reduce((s, row) => s + row[3], 0)
  const f1s = matrix.map((row, i) => {
    const tp = row[i]
    const predicted = matrix.reduce((s, r) => s + r[i], 0)
    const actual = row.reduce((a, b) => a + b, 0)
    const p = predicted ? tp / predicted : 0
    const r = actual ? tp / actual : 0
    return p + r ? (2 * p * r) / (p + r) : 0
  })
  return {
    total,
    agreement: (correct / total) * 100,
    unknownRate: (unknown / total) * 100,
    macroF1: f1s.reduce((a, b) => a + b, 0) / f1s.length,
  }
}
