export type RestockRecord = {
  id: string
  forecastSaved: string
  product: string
  sku: string
  unit: string
  forecastPeriod: string
  forecastedDemand: number
  onHandAtForecast: number
  suggestedRestock: number
  actualRestock: number | null
  receipt: { number: string; received: string; lines: string } | null
}

/** Illustrative records, newest first. Actual restock is only set when a receipt has been matched. */
export const RESTOCK_RECORDS: RestockRecord[] = [
  {
    id: 'r1',
    forecastSaved: 'Jun 10, 2025',
    product: 'Portland Cement 40kg',
    sku: 'CEM-040',
    unit: 'bags',
    forecastPeriod: 'Jun 10 – Jul 7, 2025',
    forecastedDemand: 186,
    onHandAtForecast: 64,
    suggestedRestock: 130,
    actualRestock: 150,
    receipt: { number: 'RCV-2025-0412', received: 'Jun 12, 2025', lines: '150 bags added to stock' },
  },
  {
    id: 'r2',
    forecastSaved: 'Jun 10, 2025',
    product: 'GI Roofing Sheet 8ft (Ga. 26)',
    sku: 'ROF-GI8',
    unit: 'sheets',
    forecastPeriod: 'Jun 10 – Jul 7, 2025',
    forecastedDemand: 94,
    onHandAtForecast: 40,
    suggestedRestock: 60,
    actualRestock: 48,
    receipt: { number: 'RCV-2025-0415', received: 'Jun 14, 2025', lines: '48 sheets added to stock' },
  },
  {
    id: 'r3',
    forecastSaved: 'Jun 10, 2025',
    product: 'Waterproofing Sealant 300ml',
    sku: 'SEA-300',
    unit: 'tubes',
    forecastPeriod: 'Jun 10 – Jul 7, 2025',
    forecastedDemand: 72,
    onHandAtForecast: 18,
    suggestedRestock: 60,
    actualRestock: null,
    receipt: null,
  },
  {
    id: 'r4',
    forecastSaved: 'May 27, 2025',
    product: 'PVC Pipe ½in × 10ft',
    sku: 'PVC-050',
    unit: 'lengths',
    forecastPeriod: 'May 27 – Jun 23, 2025',
    forecastedDemand: 120,
    onHandAtForecast: 85,
    suggestedRestock: 40,
    actualRestock: 40,
    receipt: { number: 'RCV-2025-0398', received: 'May 29, 2025', lines: '40 lengths added to stock' },
  },
  {
    id: 'r5',
    forecastSaved: 'May 27, 2025',
    product: 'Common Wire Nails 2in',
    sku: 'NAI-200',
    unit: 'kg',
    forecastPeriod: 'May 27 – Jun 23, 2025',
    forecastedDemand: 55,
    onHandAtForecast: 22,
    suggestedRestock: 35,
    actualRestock: 25,
    receipt: { number: 'RCV-2025-0401', received: 'May 30, 2025', lines: '25 kg added to stock' },
  },
  {
    id: 'r6',
    forecastSaved: 'May 13, 2025',
    product: 'THHN Wire 2.0mm² (150m)',
    sku: 'ELW-020',
    unit: 'rolls',
    forecastPeriod: 'May 13 – Jun 9, 2025',
    forecastedDemand: 14,
    onHandAtForecast: 6,
    suggestedRestock: 10,
    actualRestock: 12,
    receipt: { number: 'RCV-2025-0377', received: 'May 16, 2025', lines: '12 rolls added to stock' },
  },
  {
    id: 'r7',
    forecastSaved: 'May 13, 2025',
    product: 'Marine Plywood ¼in',
    sku: 'PLY-025',
    unit: 'sheets',
    forecastPeriod: 'May 13 – Jun 9, 2025',
    forecastedDemand: 38,
    onHandAtForecast: 30,
    suggestedRestock: 12,
    actualRestock: null,
    receipt: null,
  },
  {
    id: 'r8',
    forecastSaved: 'Apr 29, 2025',
    product: 'Latex Paint White 4L',
    sku: 'PNT-W04',
    unit: 'cans',
    forecastPeriod: 'Apr 29 – May 26, 2025',
    forecastedDemand: 46,
    onHandAtForecast: 20,
    suggestedRestock: 30,
    actualRestock: 30,
    receipt: { number: 'RCV-2025-0352', received: 'May 2, 2025', lines: '30 cans added to stock' },
  },
  {
    id: 'r9',
    forecastSaved: 'Apr 29, 2025',
    product: 'Deformed Bar 10mm × 6m',
    sku: 'RBR-010',
    unit: 'pcs',
    forecastPeriod: 'Apr 29 – May 26, 2025',
    forecastedDemand: 210,
    onHandAtForecast: 120,
    suggestedRestock: 100,
    actualRestock: 80,
    receipt: { number: 'RCV-2025-0355', received: 'May 3, 2025', lines: '80 pcs added to stock' },
  },
]

/** Saved 28-day forecasts still inside their period: none has completed yet. */
export const MONITORED_FORECASTS = [
  { product: 'Portland Cement 40kg', period: 'Jun 10 – Jul 7, 2025', daysLeft: 19 },
  { product: 'GI Roofing Sheet 8ft (Ga. 26)', period: 'Jun 10 – Jul 7, 2025', daysLeft: 19 },
  { product: 'Waterproofing Sealant 300ml', period: 'Jun 10 – Jul 7, 2025', daysLeft: 19 },
]

/** PROTOTYPE SAMPLE ONLY — used to preview the populated accuracy state. Not real store results. */
export const SAMPLE_EVALUATIONS = [
  { product: 'Portland Cement 40kg', unit: 'bags', period: 'Jan 6 – Feb 2', forecast: 160, actual: 142 },
  { product: 'PVC Pipe ½in × 10ft', unit: 'lengths', period: 'Jan 6 – Feb 2', forecast: 104, actual: 118 },
  { product: 'Common Wire Nails 2in', unit: 'kg', period: 'Feb 3 – Mar 2', forecast: 48, actual: 44 },
  { product: 'Latex Paint White 4L', unit: 'cans', period: 'Feb 3 – Mar 2', forecast: 40, actual: 31 },
  { product: 'Portland Cement 40kg', unit: 'bags', period: 'Mar 3 – Mar 30', forecast: 172, actual: 165 },
  { product: 'Deformed Bar 10mm × 6m', unit: 'pcs', period: 'Mar 3 – Mar 30', forecast: 190, actual: 214 },
]
