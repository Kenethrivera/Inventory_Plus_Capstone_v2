import React, { useEffect, useState } from 'react'

import { AppShell, type ForecastTab } from '../shared/components/AppShell'
import { SubTabs } from '../shared/components/SubTabs'
import { ResearchSummary } from './components/ResearchSummary'
import { EvaluationSection } from './components/EvaluationSection'
import { ClassificationSection } from './components/ClassificationSection'
import { ReplaySection } from './components/ReplaySection'
import { LimitationsSection } from './components/LimitationsSection'

export const args = {
  section: 'evaluation',
}

export const argTypes = {
  section: { control: 'select', options: ['evaluation', 'classification', 'replay', 'limitations'] },
}

type Section = 'evaluation' | 'classification' | 'replay' | 'limitations'
type Props = Partial<typeof args> & { onTabChange?: (tab: ForecastTab) => void }

export default function Research(props: Props) {
  const { section, onTabChange } = { ...args, ...props }
  const [current, setCurrent] = useState<Section>(section as Section)
  useEffect(() => setCurrent(section as Section), [section])

  return (
    <AppShell activeTab="research" onTabChange={onTabChange}>
      <ResearchSummary onOpenLimitations={() => setCurrent('limitations')} />

      <div className="mb-4 mt-7">
        <SubTabs
          value={current}
          onChange={(v) => setCurrent(v as Section)}
          options={[
            { id: 'evaluation', label: 'Historical Evaluation' },
            { id: 'classification', label: 'Seasonal Classification' },
            { id: 'replay', label: 'Historical Replay' },
            { id: 'limitations', label: 'Limitations' },
          ]}
        />
      </div>

      {current === 'evaluation' && <EvaluationSection />}
      {current === 'classification' && <ClassificationSection />}
      {current === 'replay' && <ReplaySection />}
      {current === 'limitations' && <LimitationsSection />}
    </AppShell>
  )
}
