import React from 'react'

import { LIMITATIONS } from '../../shared/data/research'

export function LimitationsSection() {
  return (
    <section className="rounded-xl border border-line bg-surface">
      <div className="border-b border-line px-4 py-3 sm:px-5">
        <h3 className="text-[15px] font-semibold">Research Limitations</h3>
        <p className="mt-0.5 text-xs text-muted">Read these before using any research figure to judge the live system.</p>
      </div>
      <ol className="divide-y divide-line">
        {LIMITATIONS.map((l) => (
          <li key={l.title} className="grid gap-1 px-4 py-3 sm:grid-cols-[220px_1fr] sm:gap-6 sm:px-5">
            <p className="text-[13px] font-semibold text-ink">{l.title}</p>
            <p className="text-[13px] leading-relaxed text-body">{l.body}</p>
          </li>
        ))}
      </ol>
    </section>
  )
}
