import React, { useState } from 'react'
import { Info } from 'lucide-react'

import { Disclosure } from '../../shared/components/Disclosure'
import { SimTag } from '../../shared/components/SimTag'
import { CLASS_FINDINGS, CLASS_METHODS, PREDICTED, SEASONS, classMetrics } from '../../shared/data/research'

export function ClassificationSection() {
  const [methodId, setMethodId] = useState(CLASS_METHODS[0].id)
  const method = CLASS_METHODS.find((m) => m.id === methodId) ?? CLASS_METHODS[0]
  const maxCell = Math.max(...method.matrix.flat())

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-[15px] font-semibold">Seasonal Classification Experiments</h3>
          <SimTag />
        </div>
        <p className="text-xs text-muted">
          Labels each product SUMMER, RAINY, NEUTRAL or UNKNOWN from its sales pattern, compared with the season profile
          used to simulate it.
        </p>
      </div>

      <div className="flex items-start gap-2.5 rounded-lg border border-line bg-surface px-3.5 py-2.5 text-[12.5px] text-body">
        <Info size={15} className="mt-0.5 shrink-0 text-muted" />
        <p>
          Experimental season discovery does not change product classifications. Seasons used for operational forecasts
          are set in Inventory and stay as they are.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        {/* Method comparison */}
        <section className="rounded-xl border border-line bg-surface">
          <p className="border-b border-line px-4 py-3 text-[13px] font-semibold">Method comparison</p>
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-line text-left text-xs text-muted">
                <th className="py-2 pl-4 pr-2 font-medium">Method</th>
                <th className="px-2 py-2 text-right font-medium">Agreement</th>
                <th className="hidden px-2 py-2 text-right font-medium sm:table-cell">Macro F1</th>
                <th className="py-2 pl-2 pr-4 text-right font-medium">UNKNOWN</th>
              </tr>
            </thead>
            <tbody>
              {CLASS_METHODS.map((m) => {
                const s = classMetrics(m.matrix)
                const active = m.id === methodId
                return (
                  <tr
                    key={m.id}
                    onClick={() => setMethodId(m.id)}
                    className={`cursor-pointer border-b border-line transition-colors duration-150 last:border-0 ${
                      active ? 'bg-accent-soft/70' : 'hover:bg-subtle'
                    }`}
                  >
                    <td className="py-2.5 pl-4 pr-2">
                      <p className={`font-medium ${active ? 'text-accent-strong' : ''}`}>{m.method}</p>
                      <p className="hidden text-xs text-muted sm:block">{m.description}</p>
                    </td>
                    <td className="tabular px-2 py-2.5 text-right font-semibold">{s.agreement.toFixed(0)}%</td>
                    <td className="tabular hidden px-2 py-2.5 text-right text-body sm:table-cell">{s.macroF1.toFixed(2)}</td>
                    <td className="tabular py-2.5 pl-2 pr-4 text-right text-body">{s.unknownRate.toFixed(0)}%</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
          <p className="border-t border-line px-4 py-2.5 text-xs text-muted">
            Select a method to see where its labels differed. {CLASS_METHODS[0].matrix.flat().reduce((a, b) => a + b, 0)}{' '}
            simulated products.
          </p>
        </section>

        {/* Confusion matrix */}
        <section className="rounded-xl border border-line bg-surface p-4">
          <p className="text-[13px] font-semibold">{method.method}</p>
          <p className="mt-0.5 text-xs text-muted">Rows: simulated season · Columns: label assigned</p>
          <div className="mt-3 overflow-hidden">
            <table className="tabular w-full table-fixed text-center text-[12px]">
              <thead>
                <tr>
                  <th className="w-[26%]" />
                  {PREDICTED.map((p) => (
                    <th key={p} className="pb-1.5 text-[10.5px] font-medium text-muted">
                      {p}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {method.matrix.map((row, i) => (
                  <tr key={SEASONS[i]}>
                    <th className="pr-2 text-left text-[10.5px] font-medium text-muted">{SEASONS[i]}</th>
                    {row.map((v, j) => {
                      const diag = i === j
                      const alpha = v === 0 ? 0 : 0.12 + (v / maxCell) * 0.6
                      return (
                        <td key={j} className="p-0.5">
                          <div
                            className={`rounded-md py-2 font-medium ${
                              v === 0 ? 'text-faint' : diag && alpha > 0.45 ? 'text-white' : 'text-ink'
                            }`}
                            style={{
                              backgroundColor: diag ? `rgba(234,106,16,${alpha})` : v ? `rgba(75,90,120,${alpha * 0.5})` : '#f9fafb',
                            }}
                          >
                            {v}
                          </div>
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs text-muted">Orange diagonal: label matched the simulated season.</p>
        </section>
      </div>

      <Disclosure title="Findings and method details" hint={`${CLASS_FINDINGS.length} observations`}>
        <ul className="list-disc space-y-1.5 pl-4">
          {CLASS_FINDINGS.map((f) => (
            <li key={f}>{f}</li>
          ))}
          <li>
            Agreement = share of products whose label matched their simulated season. Macro F1 averages precision and
            recall over SUMMER, RAINY and NEUTRAL. UNKNOWN is shown separately and counted as a non-match.
          </li>
          <li>SUMMER: peak in Mar–May. RAINY: peak in Jun–Oct. NEUTRAL: no consistent yearly peak.</li>
        </ul>
      </Disclosure>
    </div>
  )
}
