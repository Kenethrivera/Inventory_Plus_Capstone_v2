import React from 'react'
import { Info } from 'lucide-react'

import { SimTag } from '../../shared/components/SimTag'
import { CLASS_METHODS, EVALUATION, STUDY, classMetrics } from '../../shared/data/research'

export function ResearchSummary({ onOpenLimitations }: { onOpenLimitations: () => void }) {
  const agg = EVALUATION.aggregate
  const daily = EVALUATION.daily
  const best = CLASS_METHODS[0]
  const bestAgreement = classMetrics(best.matrix).agreement

  const findings = [
    {
      title: 'Calibrated seasonal forecasts had the lowest 28-day error',
      detail: `${agg[0].wape}% WAPE vs ${agg[1].wape}% for the moving-average baseline`,
      value: `${agg[0].wape}%`,
      valueLabel: '28-day WAPE',
    },
    {
      title: 'Day-level error is much higher than 28-day error',
      detail: 'Supports planning restocks on 28-day totals rather than single days',
      value: `${daily[0].wape}%`,
      valueLabel: 'Daily WAPE',
    },
    {
      title: `${best.method} matched simulated seasons most often`,
      detail: 'Agreement with the season profiles used to generate the simulated sales',
      value: `${Math.round(bestAgreement)}%`,
      valueLabel: 'Agreement',
    },
  ]

  return (
    <section>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
        <h2 className="text-base font-semibold">Seasonal Learning Laboratory</h2>
        <SimTag />
      </div>
      <p className="mt-1 text-xs text-muted">
        {STUDY.name} · {STUDY.products} products · simulated sales {STUDY.simulatedHistory}
      </p>

      <ol className="mt-4 divide-y divide-line rounded-xl border border-line bg-surface">
        {findings.map((f) => (
          <li key={f.title} className="flex items-center gap-4 px-4 py-3">
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-medium text-ink">{f.title}</p>
              <p className="mt-0.5 text-xs text-muted">{f.detail}</p>
            </div>
            <div className="shrink-0 text-right">
              <p className="tabular text-lg font-semibold leading-tight">{f.value}</p>
              <p className="text-[11px] text-muted">{f.valueLabel}</p>
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-3 flex items-start gap-2.5 rounded-lg border border-dashed border-sim/40 bg-sim-soft px-3.5 py-2.5 text-[12.5px] text-sim">
        <Info size={15} className="mt-0.5 shrink-0" />
        <p className="min-w-0 flex-1">
          These results come from synthetic simulated sales, not real customer purchases, and do not establish real-store
          accuracy.{' '}
          <button onClick={onOpenLimitations} className="font-semibold underline underline-offset-2 hover:text-ink">
            Read limitations
          </button>
        </p>
      </div>
    </section>
  )
}
