import React, { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

import { Disclosure } from '../../shared/components/Disclosure'
import { LineChart } from '../../shared/components/LineChart'
import { SimTag } from '../../shared/components/SimTag'
import { REPLAY, WINDOW_LABELS } from '../../shared/data/research'

export function ReplaySection() {
  const [productId, setProductId] = useState(REPLAY[0].id)
  const [step, setStep] = useState(6)
  const p = REPLAY.find((r) => r.id === productId) ?? REPLAY[0]
  const last = WINDOW_LABELS.length - 1

  const fc = p.forecast[step]
  const act = p.simulatedDemand[step]
  const diff = fc - act
  const absSoFar = p.forecast.slice(0, step + 1).reduce((s, f, i) => s + Math.abs(f - p.simulatedDemand[i]), 0)
  const actSoFar = p.simulatedDemand.slice(0, step + 1).reduce((a, b) => a + b, 0)

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="text-[15px] font-semibold">Historical Replay</h3>
          <SimTag />
        </div>
        <p className="text-xs text-muted">
          Re-runs past 28-day forecasts using only the data available at each origin, then compares them with simulated
          demand.
        </p>
      </div>

      <section className="rounded-xl border border-line bg-surface">
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-4 py-3">
          <select
            value={productId}
            onChange={(e) => setProductId(e.target.value)}
            className="h-8 max-w-full rounded-lg border border-line-strong bg-surface px-2 text-[12.5px] text-body outline-none focus:border-accent"
          >
            {REPLAY.map((r) => (
              <option key={r.id} value={r.id}>
                {r.product}
              </option>
            ))}
          </select>
          <span className="text-xs text-muted">Simulated season: {p.season}</span>
          <div className="ml-auto flex items-center gap-1">
            <button
              onClick={() => setStep((s) => Math.max(0, s - 1))}
              disabled={step === 0}
              className="rounded-md border border-line-strong p-1 text-body hover:bg-subtle disabled:opacity-40"
              aria-label="Previous origin"
            >
              <ChevronLeft size={15} />
            </button>
            <span className="tabular w-20 text-center text-xs font-medium">{WINDOW_LABELS[step]}</span>
            <button
              onClick={() => setStep((s) => Math.min(last, s + 1))}
              disabled={step === last}
              className="rounded-md border border-line-strong p-1 text-body hover:bg-subtle disabled:opacity-40"
              aria-label="Next origin"
            >
              <ChevronRight size={15} />
            </button>
          </div>
        </div>

        <div className="grid gap-5 p-4 lg:grid-cols-[minmax(0,1fr)_220px]">
          <LineChart
            height={220}
            labels={WINDOW_LABELS}
            highlightIndex={step}
            onPointClick={setStep}
            series={[
              { label: `Simulated demand (${p.unit})`, values: p.simulatedDemand, color: '#1c2230' },
              { label: 'Forecast made at origin', values: p.forecast, color: '#ea6a10' },
            ]}
          />
          <dl className="grid grid-cols-2 gap-x-4 gap-y-3 self-start border-t border-line pt-4 text-[13px] lg:grid-cols-1 lg:border-l lg:border-t-0 lg:pl-5 lg:pt-1">
            <div>
              <dt className="text-xs text-muted">Origin</dt>
              <dd className="font-medium">{WINDOW_LABELS[step]} · next 28 days</dd>
            </div>
            <div>
              <dt className="text-xs text-muted">Forecast</dt>
              <dd className="tabular font-medium">
                {fc} <span className="text-muted">{p.unit}</span>
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted">Simulated demand</dt>
              <dd className="tabular font-medium">
                {act} <span className="text-muted">{p.unit}</span>
              </dd>
            </div>
            <div>
              <dt className="text-xs text-muted">Forecast − demand</dt>
              <dd className="tabular font-medium">
                {diff > 0 ? '+' : diff < 0 ? '−' : ''}
                {Math.abs(diff)} <span className="text-muted">{p.unit}</span>
              </dd>
            </div>
            <div className="col-span-2 lg:col-span-1">
              <dt className="text-xs text-muted">WAPE, origins up to here</dt>
              <dd className="tabular font-medium">{((absSoFar / actSoFar) * 100).toFixed(1)}%</dd>
            </div>
          </dl>
        </div>
        <p className="border-t border-line px-4 py-2.5 text-xs text-muted">
          Click the chart or use the arrows to step through forecast origins.
        </p>
      </section>

      <Disclosure title="What replay does and does not show">
        <ul className="list-disc space-y-1.5 pl-4">
          <li>Each forecast uses only simulated sales recorded before its origin date.</li>
          <li>
            Replay shows how forecasts compared with simulated demand over time. It does not show the model learning
            online or correcting itself after an error.
          </li>
          <li>Close tracking in replay reflects the simulator’s patterns and is not evidence of future real-store accuracy.</li>
        </ul>
      </Disclosure>
    </div>
  )
}
