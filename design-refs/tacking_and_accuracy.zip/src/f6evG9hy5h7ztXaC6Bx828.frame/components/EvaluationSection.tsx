import React, { useState } from 'react'

import { LineChart } from '../../shared/components/LineChart'
import { SubTabs } from '../../shared/components/SubTabs'
import { EVALUATION, REPLAY, WINDOW_LABELS } from '../../shared/data/research'

export function EvaluationSection() {
  const [grain, setGrain] = useState<'aggregate' | 'daily'>('aggregate')
  const [productId, setProductId] = useState(REPLAY[0].id)
  const rows = EVALUATION[grain]
  const product = REPLAY.find((p) => p.id === productId) ?? REPLAY[0]

  // Holdout = last 6 windows; baseline approximated by the preceding window's demand.
  const labels = WINDOW_LABELS.slice(7)
  const actual = product.simulatedDemand.slice(7)
  const calibrated = product.forecast.slice(7)
  const baseline = product.simulatedDemand.slice(6, 12)

  return (
    <div className="space-y-4">
      <p className="max-w-2xl text-[13px] text-body">
        Each method forecast periods it had not seen, and its forecasts were compared with the simulated sales for those
        periods.
      </p>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.35fr)]">
        {/* Model comparison */}
        <section className="rounded-xl border border-line bg-surface">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3">
            <p className="text-[13px] font-semibold">Model comparison</p>
            <SubTabs
              value={grain}
              onChange={(v) => setGrain(v as 'aggregate' | 'daily')}
              options={[
                { id: 'aggregate', label: '28-day' },
                { id: 'daily', label: 'Daily' },
              ]}
            />
          </div>
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-line text-left text-xs text-muted">
                <th className="py-2 pl-4 pr-2 font-medium">Model</th>
                <th className="px-2 py-2 text-right font-medium">WAPE</th>
                <th className="py-2 pl-2 pr-4 text-right font-medium">Bias</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.model} className="border-b border-line last:border-0">
                  <td className="py-2.5 pl-4 pr-2">
                    <p className={`font-medium ${r.operational ? 'text-accent-strong' : 'text-ink'}`}>{r.model}</p>
                    <p className="text-xs text-muted">{r.note}</p>
                  </td>
                  <td className="tabular px-2 py-2.5 text-right font-semibold">{r.wape.toFixed(1)}%</td>
                  <td className="tabular py-2.5 pl-2 pr-4 text-right text-body">
                    {r.bias > 0 ? '+' : '−'}
                    {Math.abs(r.bias).toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <dl className="space-y-1 border-t border-line px-4 py-2.5 text-xs text-muted">
            <div>
              <dt className="inline font-medium text-body">WAPE</dt> — total forecast error compared with total sales.
              Lower is better.
            </div>
            <div>
              <dt className="inline font-medium text-body">Bias</dt> — + means forecasts ran high overall, − means they
              ran low.
            </div>
            {grain === 'daily' && <div>Bias matches the 28-day view because the totals compared are the same.</div>}
          </dl>
        </section>

        {/* Forecast vs actual */}
        <section className="rounded-xl border border-line bg-surface p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <p className="text-[13px] font-semibold">Forecast vs simulated actual, 28-day totals</p>
            <select
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              className="h-8 max-w-full rounded-lg border border-line-strong bg-surface px-2 text-[12.5px] text-body outline-none focus:border-accent"
            >
              {REPLAY.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.product}
                </option>
              ))}
            </select>
          </div>
          <LineChart
            height={200}
            labels={labels}
            series={[
              { label: `Simulated actual (${product.unit})`, values: actual, color: '#1c2230' },
              { label: 'Calibrated seasonal', values: calibrated, color: '#ea6a10' },
              { label: 'Moving-average baseline', values: baseline, color: '#9aa1ad', dashed: true },
            ]}
          />
        </section>
      </div>
    </div>
  )
}
