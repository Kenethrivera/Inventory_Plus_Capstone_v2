import React, { useEffect, useState } from 'react'

import { AppShell, type ForecastTab } from '../shared/components/AppShell'
import { SubTabs } from '../shared/components/SubTabs'
import { RestockRecords } from './components/RestockRecords'
import { ForecastAccuracy } from './components/ForecastAccuracy'

export const args = {
  section: 'records',
  accuracyData: 'awaiting',
  showAllRecords: false,
}

export const argTypes = {
  section: { control: 'radio', options: ['records', 'accuracy'] },
  accuracyData: { control: 'radio', options: ['awaiting', 'sample'] },
  showAllRecords: { control: 'boolean' },
}

type Props = Partial<typeof args> & { onTabChange?: (tab: ForecastTab) => void }

export default function TrackingAccuracy(props: Props) {
  const { section, accuracyData, showAllRecords, onTabChange } = { ...args, ...props }
  const [current, setCurrent] = useState(section)
  useEffect(() => setCurrent(section), [section])

  return (
    <AppShell activeTab="tracking" onTabChange={onTabChange}>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <SubTabs
          value={current}
          onChange={setCurrent}
          options={[
            { id: 'records', label: 'Restock Records' },
            { id: 'accuracy', label: 'Forecast Accuracy' },
          ]}
        />
        <p className="text-xs text-muted">
          {current === 'records'
            ? 'What was forecast, what was suggested, and what was actually added to stock.'
            : 'Forecasted customer demand compared with recorded customer sales.'}
        </p>
      </div>

      {current === 'records' ? (
        <RestockRecords initialShowAll={showAllRecords} />
      ) : (
        <ForecastAccuracy data={accuracyData === 'sample' ? 'sample' : 'awaiting'} />
      )}
    </AppShell>
  )
}
