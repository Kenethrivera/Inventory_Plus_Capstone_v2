import React, { useMemo, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { ChevronDown, Search, X } from 'lucide-react'

import { RESTOCK_RECORDS, type RestockRecord } from '../../shared/data/restockRecords'

const PAGE = 5
type MatchFilter = 'all' | 'matched' | 'unmatched'

export function RestockRecords({ initialShowAll = false }: { initialShowAll?: boolean }) {
  const [query, setQuery] = useState('')
  const [match, setMatch] = useState<MatchFilter>('all')
  const [showAll, setShowAll] = useState(initialShowAll)
  const [openId, setOpenId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return RESTOCK_RECORDS.filter((r) => {
      if (q && !`${r.product} ${r.sku}`.toLowerCase().includes(q)) return false
      if (match === 'matched' && r.actualRestock === null) return false
      if (match === 'unmatched' && r.actualRestock !== null) return false
      return true
    })
  }, [query, match])

  const visible = showAll ? filtered : filtered.slice(0, PAGE)
  const toggle = (id: string) => setOpenId((cur) => (cur === id ? null : id))

  return (
    <section className="rounded-xl border border-line bg-surface">
      {/* Toolbar */}
      <div className="flex flex-col gap-2.5 border-b border-line p-3 sm:flex-row sm:items-center">
        <label className="relative flex-1 sm:max-w-xs">
          <Search size={15} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-faint" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search product or SKU"
            className="h-9 w-full rounded-lg border border-line-strong bg-surface pl-8 pr-8 text-[13px] outline-none placeholder:text-faint focus:border-accent focus:ring-2 focus:ring-accent/15"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded p-0.5 text-faint hover:text-ink"
              aria-label="Clear search"
            >
              <X size={14} />
            </button>
          )}
        </label>
        <select
          value={match}
          onChange={(e) => setMatch(e.target.value as MatchFilter)}
          className="h-9 rounded-lg border border-line-strong bg-surface px-2.5 text-[13px] text-body outline-none focus:border-accent sm:w-52"
        >
          <option value="all">All records</option>
          <option value="matched">With recorded restock</option>
          <option value="unmatched">No recorded match</option>
        </select>
        <p className="text-xs text-muted sm:ml-auto">
          {filtered.length} {filtered.length === 1 ? 'record' : 'records'}
        </p>
      </div>

      {filtered.length === 0 ? (
        <div className="px-4 py-12 text-center">
          <p className="text-sm font-medium">No records match “{query}”</p>
          <p className="mt-1 text-xs text-muted">Try a different product name or clear the filter.</p>
        </div>
      ) : (
        <>
          {/* Desktop table */}
          <table className="hidden w-full text-[13px] md:table">
            <thead>
              <tr className="border-b border-line text-left text-xs font-medium text-muted">
                <th className="py-2.5 pl-4 pr-3 font-medium">Date / Product</th>
                <th className="px-3 py-2.5 text-right font-medium">Forecasted Demand</th>
                <th className="px-3 py-2.5 text-right font-medium">Suggested Restock</th>
                <th className="px-3 py-2.5 text-right font-medium">Actual Restock</th>
                <th className="px-3 py-2.5 text-right font-medium">Difference</th>
                <th className="w-10 py-2.5 pr-3" />
              </tr>
            </thead>
            <tbody>
              {visible.map((r) => {
                const open = openId === r.id
                return (
                  <React.Fragment key={r.id}>
                    <tr
                      onClick={() => toggle(r.id)}
                      className={`cursor-pointer border-b border-line transition-colors duration-150 last:border-0 ${
                        open ? 'bg-accent-soft/60' : 'hover:bg-subtle'
                      }`}
                    >
                      <td className="py-2.5 pl-4 pr-3">
                        <p className="text-xs text-muted">{r.forecastSaved}</p>
                        <p className="font-medium text-ink">{r.product}</p>
                      </td>
                      <td className="tabular px-3 py-2.5 text-right">
                        <Qty n={r.forecastedDemand} unit={r.unit} />
                      </td>
                      <td className="tabular px-3 py-2.5 text-right">
                        <Qty n={r.suggestedRestock} unit={r.unit} />
                      </td>
                      <td className="tabular px-3 py-2.5 text-right">
                        <Actual r={r} />
                      </td>
                      <td className="tabular px-3 py-2.5 text-right">
                        <Difference r={r} />
                      </td>
                      <td className="py-2.5 pr-3 text-right">
                        <ChevronDown
                          size={15}
                          className={`ml-auto text-faint transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
                        />
                      </td>
                    </tr>
                    <AnimatePresence initial={false}>
                      {open && (
                        <tr className="border-b border-line bg-subtle">
                          <td colSpan={6} className="p-0">
                            <Expand>
                              <Details r={r} />
                            </Expand>
                          </td>
                        </tr>
                      )}
                    </AnimatePresence>
                  </React.Fragment>
                )
              })}
            </tbody>
          </table>

          {/* Mobile records */}
          <ul className="divide-y divide-line md:hidden">
            {visible.map((r) => {
              const open = openId === r.id
              return (
                <li key={r.id} className={open ? 'bg-accent-soft/50' : ''}>
                  <button onClick={() => toggle(r.id)} className="w-full px-4 py-3 text-left">
                    <div className="flex items-start gap-2">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs text-muted">{r.forecastSaved}</p>
                        <p className="truncate text-[13px] font-medium">{r.product}</p>
                      </div>
                      <ChevronDown
                        size={15}
                        className={`mt-1 shrink-0 text-faint transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
                      />
                    </div>
                    <dl className="tabular mt-2 grid grid-cols-2 gap-x-4 gap-y-1.5 text-[12px]">
                      <MobileStat label="Forecasted">
                        <Qty n={r.forecastedDemand} unit={r.unit} />
                      </MobileStat>
                      <MobileStat label="Suggested">
                        <Qty n={r.suggestedRestock} unit={r.unit} />
                      </MobileStat>
                      <MobileStat label="Actual">
                        <Actual r={r} />
                      </MobileStat>
                      <MobileStat label="Difference">
                        <Difference r={r} />
                      </MobileStat>
                    </dl>
                  </button>
                  <AnimatePresence initial={false}>
                    {open && (
                      <Expand>
                        <div className="border-t border-line bg-subtle">
                          <Details r={r} />
                        </div>
                      </Expand>
                    )}
                  </AnimatePresence>
                </li>
              )
            })}
          </ul>
        </>
      )}

      {/* Footer */}
      <div className="flex flex-col gap-2 border-t border-line px-4 py-2.5 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
        <p>Difference = Actual Restock − Suggested Restock. Positive means more was restocked than suggested.</p>
        {filtered.length > PAGE && (
          <button
            onClick={() => setShowAll((s) => !s)}
            className="self-start whitespace-nowrap font-medium text-accent hover:text-accent-strong sm:self-auto"
          >
            {showAll ? 'Show 5 most recent' : `View all records (${filtered.length})`}
          </button>
        )}
      </div>
    </section>
  )
}

function Qty({ n, unit }: { n: number; unit: string }) {
  return (
    <span className="whitespace-nowrap">
      <span className="font-medium text-ink">{n.toLocaleString()}</span> <span className="text-muted">{unit}</span>
    </span>
  )
}

function Actual({ r }: { r: RestockRecord }) {
  if (r.actualRestock === null) return <span className="whitespace-nowrap text-muted italic">No recorded match</span>
  return <Qty n={r.actualRestock} unit={r.unit} />
}

function Difference({ r }: { r: RestockRecord }) {
  if (r.actualRestock === null) return <span className="text-faint">—</span>
  const d = r.actualRestock - r.suggestedRestock
  const sign = d > 0 ? '+' : d < 0 ? '−' : ''
  return (
    <span className="whitespace-nowrap">
      <span className={`font-medium ${d === 0 ? 'text-muted' : 'text-ink'}`}>
        {sign}
        {Math.abs(d)}
      </span>{' '}
      <span className="text-muted">{r.unit}</span>
    </span>
  )
}

function MobileStat({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex min-w-0 items-baseline justify-between gap-2">
      <dt className="text-muted">{label}</dt>
      <dd className="truncate text-right">{children}</dd>
    </div>
  )
}

function Expand({ children }: { children: React.ReactNode }) {
  const reduce = useReducedMotion()
  return (
    <motion.div
      initial={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
      animate={reduce ? { opacity: 1 } : { height: 'auto', opacity: 1 }}
      exit={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }}
      transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
      className="overflow-hidden"
    >
      {children}
    </motion.div>
  )
}

function Details({ r }: { r: RestockRecord }) {
  const items: [string, React.ReactNode][] = [
    ['Forecast saved', r.forecastSaved],
    ['Forecast period', `${r.forecastPeriod} (28 days)`],
    ['Inventory unit', r.unit],
    ['On hand when forecast was saved', `${r.onHandAtForecast} ${r.unit}`],
    ['SKU', r.sku],
  ]
  return (
    <div className="grid gap-5 px-4 py-4 md:grid-cols-[1.4fr_1fr] md:pl-4 md:pr-12">
      <dl className="grid grid-cols-1 gap-x-6 gap-y-2.5 text-[12.5px] sm:grid-cols-2">
        {items.map(([k, v]) => (
          <div key={k}>
            <dt className="text-xs text-muted">{k}</dt>
            <dd className="mt-0.5 text-ink">{v}</dd>
          </div>
        ))}
      </dl>
      <div className="md:border-l md:border-line md:pl-5">
        <p className="text-xs text-muted">Receipt evidence</p>
        {r.receipt ? (
          <div className="mt-1 text-[12.5px]">
            <p className="font-medium text-ink">{r.receipt.number}</p>
            <p className="text-body">Received {r.receipt.received}</p>
            <p className="text-body">{r.receipt.lines}</p>
          </div>
        ) : (
          <p className="mt-1 text-[12.5px] text-body">
            No receipt has been matched to this recommendation, so no actual restock is recorded.
          </p>
        )}
      </div>
    </div>
  )
}
