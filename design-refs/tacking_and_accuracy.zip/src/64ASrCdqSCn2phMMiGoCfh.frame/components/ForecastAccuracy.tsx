import React from 'react'
import { Hourglass } from 'lucide-react'

import { Disclosure } from '../../shared/components/Disclosure'
import { LineChart } from '../../shared/components/LineChart'
import { MONITORED_FORECASTS, SAMPLE_EVALUATIONS } from '../../shared/data/restockRecords'

export function ForecastAccuracy({ data }: { data: 'awaiting' | 'sample' }) {
  return (
    <div className="space-y-4">
      {data === 'awaiting' ? <Awaiting /> : <Populated />}
      <Disclosure title="How is forecast performance measured?" hint="WAPE and Bias, in plain terms">
        <dl className="grid gap-4 sm:grid-cols-2">
          <div>
            <dt className="font-semibold text-ink">WAPE — Forecast Error</dt>
            <dd className="mt-1">
              Measures total absolute forecast error relative to actual sales. Lower is better.
            </dd>
            <dd className="mt-2 rounded-lg bg-subtle px-3 py-2 font-mono text-xs text-body">
              Σ |forecast − actual sales| ÷ Σ actual sales
            </dd>
          </div>
          <div>
            <dt className="font-semibold text-ink">Bias — Forecast Tendency</dt>
            <dd className="mt-1">
              Positive means predicted too much; negative means predicted too little. Near zero means more balanced
              overall, but does not guarantee small errors.
            </dd>
            <dd className="mt-2 rounded-lg bg-subtle px-3 py-2 font-mono text-xs text-body">
              (Σ forecast − Σ actual sales) ÷ Σ actual sales
            </dd>
          </div>
        </dl>
        <p className="mt-4 text-xs text-muted">
          Only forecasts whose full 28-day period has ended, with recorded sales for that period, are evaluated. Restock
          quantities are not part of these measures.
        </p>
      </Disclosure>
    </div>
  )
}

function Awaiting() {
  return (
    <section className="rounded-xl border border-line bg-surface">
      <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[1fr_1.1fr] lg:gap-10">
        <div>
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-accent-soft text-accent">
            <Hourglass size={18} />
          </span>
          <h2 className="mt-3 text-lg font-semibold">Awaiting completed forecasts</h2>
          <p className="mt-1.5 max-w-md text-[13px] leading-relaxed text-body">
            Forecast accuracy will appear after saved forecast periods end and sufficient sales data becomes available
            for comparison.
          </p>
          <dl className="mt-5 grid grid-cols-3 divide-x divide-line rounded-lg border border-line">
            <Stat label="Saved forecasts monitored" value="3" />
            <Stat label="Completed eligible evaluations" value="0" />
            <Stat label="Current status" value="Awaiting completion" small />
          </dl>
        </div>
        <div>
          <p className="text-xs font-medium text-muted">Monitored 28-day forecasts</p>
          <ul className="mt-2 divide-y divide-line border-y border-line">
            {MONITORED_FORECASTS.map((f) => (
              <li key={f.product} className="flex items-center gap-3 py-2.5 text-[13px]">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{f.product}</p>
                  <p className="text-xs text-muted">{f.period}</p>
                </div>
                <div className="w-28 shrink-0 text-right">
                  <p className="tabular text-xs text-body">{f.daysLeft} days left</p>
                  <div className="mt-1 h-1 overflow-hidden rounded-full bg-line">
                    <div className="h-full rounded-full bg-accent" style={{ width: `${((28 - f.daysLeft) / 28) * 100}%` }} />
                  </div>
                </div>
              </li>
            ))}
          </ul>
          <p className="mt-2.5 text-xs text-muted">
            Each forecast becomes eligible once its period ends and its sales have been recorded.
          </p>
        </div>
      </div>
    </section>
  )
}

function Stat({ label, value, small }: { label: string; value: string; small?: boolean }) {
  return (
    <div className="min-w-0 px-3 py-2.5">
      <dt className="text-[11px] leading-tight text-muted">{label}</dt>
      <dd className={`tabular mt-1 font-semibold text-ink ${small ? 'text-[13px] leading-tight' : 'text-xl'}`}>{value}</dd>
    </div>
  )
}

function Populated() {
  const rows = SAMPLE_EVALUATIONS
  const sumAbs = rows.reduce((s, r) => s + Math.abs(r.forecast - r.actual), 0)
  const sumAct = rows.reduce((s, r) => s + r.actual, 0)
  const sumFc = rows.reduce((s, r) => s + r.forecast, 0)
  const wape = (sumAbs / sumAct) * 100
  const bias = ((sumFc - sumAct) / sumAct) * 100

  const periods = Array.from(new Set(rows.map((r) => r.period)))
  const trend = periods.map((p) => {
    const rs = rows.filter((r) => r.period === p)
    const a = rs.reduce((s, r) => s + Math.abs(r.forecast - r.actual), 0)
    const t = rs.reduce((s, r) => s + r.actual, 0)
    return { period: p, wape: Math.round((a / t) * 1000) / 10 }
  })

  return (
    <section className="rounded-xl border border-line bg-surface">
      <div className="flex flex-wrap items-center gap-2 border-b border-dashed border-sim/40 bg-sim-soft px-4 py-2 text-xs text-sim">
        <span className="font-semibold">Prototype sample data</span>
        <span>Illustrates the populated layout. These are not real store results.</span>
      </div>

      <div className="grid gap-6 p-5 sm:p-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.3fr)] lg:gap-10">
        <div>
          <p className="text-xs font-medium text-muted">WAPE — Forecast Error</p>
          <p className="tabular mt-1 text-4xl font-semibold tracking-tight">{wape.toFixed(1)}%</p>
          <p className="mt-1 text-xs text-muted">Lower is better · across all evaluated periods</p>

          <dl className="mt-5 grid grid-cols-2 divide-x divide-line border-y border-line">
            <div className="py-3 pr-3">
              <dt className="text-xs text-muted">Bias — Forecast Tendency</dt>
              <dd className="tabular mt-0.5 text-lg font-semibold">
                {bias > 0 ? '+' : bias < 0 ? '−' : ''}
                {Math.abs(bias).toFixed(1)}%
              </dd>
              <dd className="text-xs text-muted">
                {Math.abs(bias) < 1 ? 'Balanced overall' : bias > 0 ? 'Predicted more than sold' : 'Predicted less than sold'}
              </dd>
            </div>
            <div className="py-3 pl-4">
              <dt className="text-xs text-muted">Eligible completed evaluations</dt>
              <dd className="tabular mt-0.5 text-lg font-semibold">{rows.length}</dd>
              <dd className="text-xs text-muted">across {periods.length} forecast periods</dd>
            </div>
          </dl>
        </div>

        <div>
          <p className="mb-1 text-xs font-medium text-muted">WAPE by forecast period</p>
          {trend.length >= 2 ? (
            <LineChart
              height={170}
              unit="%"
              labels={trend.map((t) => t.period)}
              series={[{ label: 'WAPE', values: trend.map((t) => t.wape), color: '#ea6a10' }]}
            />
          ) : (
            <p className="text-xs text-muted">A trend appears once two or more comparable periods are complete.</p>
          )}
        </div>
      </div>

      <div className="border-t border-line">
        <p className="px-4 pb-1 pt-3 text-xs font-medium text-muted sm:px-6">Completed evaluations</p>
        <table className="hidden w-full text-[13px] md:table">
          <thead>
            <tr className="border-b border-line text-left text-xs text-muted">
              <th className="py-2 pl-6 pr-3 font-medium">Period / Product</th>
              <th className="px-3 py-2 text-right font-medium">Forecasted demand</th>
              <th className="px-3 py-2 text-right font-medium">Actual sales</th>
              <th className="py-2 pl-3 pr-6 text-right font-medium">Forecast − Actual</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => {
              const d = r.forecast - r.actual
              return (
                <tr key={i} className="border-b border-line last:border-0">
                  <td className="py-2.5 pl-6 pr-3">
                    <p className="text-xs text-muted">{r.period}</p>
                    <p className="font-medium">{r.product}</p>
                  </td>
                  <td className="tabular px-3 py-2.5 text-right">
                    {r.forecast} <span className="text-muted">{r.unit}</span>
                  </td>
                  <td className="tabular px-3 py-2.5 text-right">
                    {r.actual} <span className="text-muted">{r.unit}</span>
                  </td>
                  <td className="tabular py-2.5 pl-3 pr-6 text-right">
                    {d > 0 ? '+' : d < 0 ? '−' : ''}
                    {Math.abs(d)} <span className="text-muted">{r.unit}</span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <ul className="divide-y divide-line md:hidden">
          {rows.map((r, i) => {
            const d = r.forecast - r.actual
            return (
              <li key={i} className="px-4 py-2.5 text-[12.5px]">
                <p className="text-xs text-muted">{r.period}</p>
                <p className="font-medium">{r.product}</p>
                <p className="tabular mt-1 text-body">
                  Forecast {r.forecast} · Sold {r.actual} · {d > 0 ? '+' : d < 0 ? '−' : ''}
                  {Math.abs(d)} {r.unit}
                </p>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
