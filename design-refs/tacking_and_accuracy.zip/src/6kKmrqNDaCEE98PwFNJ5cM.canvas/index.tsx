import ForecastingRestocking from '../9K9VXnvPjqVsUZ3h7kR1ZC.prototype'

export const placements = [
  place(ForecastingRestocking, { id: 'forecasting', x: 0, y: 0 }),
]
