import React, { useState } from 'react'

import TrackingAccuracy from '../64ASrCdqSCn2phMMiGoCfh.frame'
import Research from '../f6evG9hy5h7ztXaC6Bx828.frame'
import type { ForecastTab } from '../shared/components/AppShell'

const TRACKING = '64ASrCdqSCn2phMMiGoCfh'
const RESEARCH = 'f6evG9hy5h7ztXaC6Bx828'

/** The size every frame draws at, unless one exports its own. */
export const viewport = 'web'

export const args = {
  accuracyData: 'awaiting',
}

export const argTypes = {
  accuracyData: { control: 'radio', options: ['awaiting', 'sample'] },
}

type Props = Partial<typeof args> & { start?: string }

export default function ForecastingRestocking(props: Props) {
  const { accuracyData, start } = { ...args, ...props }
  const [screen, setScreen] = useState(() => start ?? TRACKING)

  // Overview and Product Forecast are designed separately; their tabs stay in place but do not navigate here.
  const onTabChange = (tab: ForecastTab) => {
    if (tab === 'tracking') setScreen(TRACKING)
    if (tab === 'research') setScreen(RESEARCH)
  }

  if (screen === RESEARCH) return <Research onTabChange={onTabChange} />
  return <TrackingAccuracy accuracyData={accuracyData} onTabChange={onTabChange} />
}
