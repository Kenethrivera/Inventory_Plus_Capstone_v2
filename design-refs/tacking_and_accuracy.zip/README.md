# Untitled

Exported from [this OS](https://www.magicpatterns.com/os/brgBmS9wDbFzGfH4PoAuSb) on [Magic Patterns](https://magicpatterns.com).

## Getting started

1. `npm install`
2. `npm run dev`, then open the page you want from the home page

## Pages

- [Forecasting & Restocking](pages/forecasting-restocking/) — `src/9K9VXnvPjqVsUZ3h7kR1ZC.prototype`
- [Research](pages/research/) — `src/f6evG9hy5h7ztXaC6Bx828.frame`
- [Tracking & Accuracy](pages/tracking-accuracy/) — `src/64ASrCdqSCn2phMMiGoCfh.frame`
