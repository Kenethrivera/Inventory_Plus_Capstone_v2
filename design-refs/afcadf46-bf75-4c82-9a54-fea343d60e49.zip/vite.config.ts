import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { defineConfig } from 'vite'

const root = dirname(fileURLToPath(import.meta.url))

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    rollupOptions: {
      input: {
        main: resolve(root, 'index.html'),
        "forecasting-overview": resolve(root, 'pages/forecasting-overview/index.html'),
        "overview": resolve(root, 'pages/overview/index.html'),
        "product-detail": resolve(root, 'pages/product-detail/index.html'),
        "research": resolve(root, 'pages/research/index.html'),
        "tracking-accuracy": resolve(root, 'pages/tracking-accuracy/index.html'),
      },
    },
  },
})
