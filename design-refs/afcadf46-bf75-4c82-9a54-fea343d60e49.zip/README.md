# Untitled

Exported from [this OS](https://www.magicpatterns.com/os/p844Le4NjBmoGbMoUJXnoW) on [Magic Patterns](https://magicpatterns.com).

## Getting started

1. `npm install`
2. `npm run dev`, then open the page you want from the home page

## Pages

- [Forecasting Overview](pages/forecasting-overview/) — `src/7F8cJWcCCtKdZLLbbziydB.prototype`
- [Overview](pages/overview/) — `src/n6bbyevvKwBgWSQSR7Vw3z.frame`
- [Product Detail](pages/product-detail/) — `src/6EP5TnPFF4K5yxYMkaYTzE.frame`
- [Research](pages/research/) — `src/au5ToZiJStKRm5mKSASktB.frame`
- [Tracking & Accuracy](pages/tracking-accuracy/) — `src/1H3Q4oMStkkZaY7toRpXTY.frame`
