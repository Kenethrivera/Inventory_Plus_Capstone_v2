import ForecastingOverview from '../7F8cJWcCCtKdZLLbbziydB.prototype'

export const placements = [
  place(ForecastingOverview, { id: 'prototype-7F8cJWcC', x: 0, y: 0 }),
]
